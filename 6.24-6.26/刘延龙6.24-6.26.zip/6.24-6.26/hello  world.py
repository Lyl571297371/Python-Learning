#安装测试文本编辑器Geany
print("hello  python world")

